
    <!-- Main Content -->
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-lg-offset-2 col-md-10 col-md-offset-1">
                <p>Seorang extrovert yang lemah pengetahuannya. Pendatang baru dunia IT dan masih menuntut ilmu di Program Studi Teknik Informatika Universitas Mataram</p>
                <p>Tertarik dengan web developing dan mobile programming. Berharap suatu saat bisa menjadi konsultan IT.</p>
                <p>Lahir di sebuah pulau kecil nan indah yang disebut Lombok. dan dikota kecil bernama Mataram.</p>
            </div>
        </div>
    </div>
