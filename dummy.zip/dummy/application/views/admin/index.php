        <div id="page-content-wrapper">
           <div class="row">
                <div class="col-lg-12">
                    <div class="jumbotron">
                        <h1>Ilham Bintang</h1>
                        <p>Silahkan buka menu yang lain -_-</p>
                        <p><a class="btn btn-primary btn-lg" role="button">Gak bisa di klik</a>
                        </p>
                    </div>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>