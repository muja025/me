   <div id="wrapper">
        <!-- Sidebar -->
        <div id="sidebar-wrapper">
            <ul class="sidebar-nav">
                <li class="sidebar-brand">
                    <a href="#">
                        Ilham Bintang
                    </a>
                </li>
                <a href="<?php echo base_url(); ?>crud">
                    <li>
                        Dashboard
                    </li>
                </a>
                <a href="<?php echo base_url(); ?>crud/messages">
                    <li>
                        Messages
                    </li>
                </a>
                <a href="<?php echo base_url(); ?>crud/post">
                    <li>
                        Post
                    </li>
                </a>
                <a href="<?php echo base_url(); ?>crud/komentar">
                    <li>
                        Komentar
                    </li>
                </a>
                <a href="<?php echo base_url(); ?>login/logout">
                    <li>
                        Logout
                    </li>
                </a>
            </ul>
        </div>
        <!-- /#sidebar-wrapper -->

        <!-- Page Content -->
        